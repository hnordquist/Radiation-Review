INCC 5.1.2.1 for the IAEA
Feb. 24, 2010
LA-CC-98-08

Note: To examine the new features and bug fixes in this release,
Scroll down a few pages to the CHANGES section.

Readme for INCC - LA-UR-99-4634

Safeguards and Security Systems Group, N-4
Safeguards Science and Technology Group, N-1
Nuclear Nonproliferation Division
Los Alamos National Laboratory

Original Author: Bill Harker
Maintaining Author: Joseph F. Longo

Software Version:
This document applies to version 5.* of INCC.

Sponsorship:
This work was supported, in part, by the United States Member
State Support Program to IAEA Safeguards; the U.S. Department
of Energy, Office of Nonproliferation and National Security,
International Safeguards Division; and the U.S. Department of
Energy, Office of Safeguards and Security.

Copyright � Los Alamos National Security, LLC, (LANS), 2010.

The INCC software and accompanying documentation is maintained by
the Safeguards Science and Technology Group (N-1) and
the Safeguards and Security Systems Group (N-4).

The INCC software and documentation is produced under Contract No.
DE-AC52-06NA25396 with the U.S. Department of Energy (DOE).
LANS has certain rights in the program pursuant to the contract,
and the program should not be copied or distributed outside your
organization. All rights in the program are reserved by the DOE
and LANS. Neither the U.S. Government nor LANS makes any warranty,
express or implied, or assumes any liability or responsibility for the
use of this software.


PURPOSE

These release notes provide information on INCC version 5.*

These notes contain a list of changes from versions 5.00,
instructions on installing the program,
and a list of files that are included with this release.

REFERENCES

For full information about this software consult the
INCC Version 5.00 Users Manual

INCOMPATIBILITIES

Version 5.** of the software and its database are incompatible with
versions prior to 5.00.  However, an INCC version 3.2x or 4.0x
database created using the File | Backup All Data menu option can
be imported into any INCC version 5 using the File | Restore All Data
menu option.

Beginning with version 3.00, measurement data files created using the
File | Save As/Export | Transfer option can be read into the database
of any more recent version of INCC by using the
File | Get External Data | Transfer option.

Also, beginning with version 3.00, detector parameter files and
calibration parameter files created using the
File | Save As/Export | Initial Data option can be read into the
database of any more recent version of INCC by using the
File | Get External Data | Initial Data option.

This version of the software is only compatible with
Deming version 1.00 or later.

OPERATING SYSTEM REQUIREMENTS

INCC runs on most 32-bit Microsoft Windows operating systems.
Windows 2000, Windows XP Home, or Professional are preferred
and provide the best performance. The author believes INCC functions
correctly (when properly configured) on all Windows 32 and 64-bit
operating systems, including Windows Vista, Windows Server 200n,
and Windows 7, but asserts no warranty. 


**CHANGES

CHANGES FROM VERSION  5.1.1.1 to VERSION 5.1.2.0

New Features:
INCC-5: Add total U mass to the printout of the U results for Passive
        Calibration Curve
INCC-9: INCC should create missing config and database automatically.
        INCC now creates facility configuration and database materials
        automatically when running under IRS and the materials are missing.

CHANGES FROM VERSION  5.1.1.1 to VERSION 5.1.2.0

New Features:
INCC-3: Add the capability to select Singles or Doubles for the Calibration Curve
INCC-4: Add Aux ratios with global toggle to analysis results

Bug Fixes:
BMEND-5: Prove IR/OP works with B2R1 RAD/INCC (see BMEND-100)
BMEND-100: No ACK back to IR when using the INCC /IMPORT /IR scheme
BMEND-120: New INCC command line confused by legacy SKIP_RUNNING_MSG parameter


CHANGES FROM VERSION  5.1.1.0 to VERSION 5.1.1.1

New Features:
1: INCC Collar Thermal Mode Poison Absorption Factor selector.


CHANGES FROM VERSION  5.1.0.5 to VERSION 5.1.1.0

New Features:
1: New data fields for verification and summary reporting: Pu240e,
   multiplication corrected doubles and error, predelay and gate
   summary report fields.
2: Multiplicity analysis Efficiency Correction factor.
3: High Voltage plateau measurement feature.
4: INCC command line enhancements, including new flags for automatic
   import of detectors and parameters, (DOE/Eur only).


CHANGES FROM VERSION  5.1.0.4 to VERSION 5.1.0.5

New Features:
1: The deadtime coefficient term, C, is restored to the value
   in INCC 5.04 and earlier.
2: Optional silent creation of missing DATA folders on database
   selection and restoration enabled. See the options on the 'Some
   Settings' dialog.
3: When installed as part of a LANL UNARM IRS system, INCC can take
   advantage of the Facility Manager's (FM) configuration information.
   INCC uses the FM if the InccCfg.ini exists in the same folder as
   incc.exe, containing these two lines:
       [DEFAULT_FACILITY_INFO]
       bUSEIRS=y

Bug Fixes:

1. #196 Add-a-source ir.idb file for Integrated Review is incorrectly
        written.
2. #496 Incorrect "missing 'Data' folder" prompt appears under certain
        rare conditions.
3. Database selection sometimes reverted silently to previous selection.

CHANGES FROM VERSION  5.1.0.3 to VERSION 5.1.0.4

New Features:
1: Improved messages for database restoration processing. Missing 
   DATA folders may now be created automatically during database
   restoration.
2: Improved behavior and information on the database selector dialog.
3: Newly created summary report windows are maximized, for readability.
4: During the IMPORT process, suppress the general automatic dialog,
   and all Curium Ratio automatic confirmation dialogs. Turn all
   interaction with the user off. Control dialog suppression using
   the 'Some Settings' dialog, available from the 'Maintain' menu.
5: Make available alternate Pu240 Effective coefficients. Select
   from four alternative sets of coefficient values using the
   'Select Pu240e Coefficients' dialog. This feature available *only*
   in the Euratom INCC version.

Bug Fixes:
1: Fixed intermittent failure accessing external Deming curve fitting
   program.
2: Local v. remote execution handling completed.
3: INCC now attempts to find a default database when the expected
   database folder is unavailable at start time.
4: INCC /IMPORT feature check for the Operator Review tool is now
   optional. The check is off by default.
5: Certain missing DATA folder warnings no longer use an outdated path.

CHANGES FROM VERSION  5.1.0.2 to VERSION 5.1.0.3
New Features:
1: Add-A-Source correction factor choice added to the measurement and
   summary report tables

CHANGES FROM VERSION  5.1.0.1 to VERSION 5.1.0.2
Bug Fixes:
1: Weighted Multiplicity Analysis coefficients entered from the user
interface previously were limited to a range of 0.0 . . . 2.0. The
limits are now expanded to -1e6 . . . 1e6.

CHANGES FROM VERSION  5.1.0.0 to VERSION 5.1.0.1
Bug Fixes:
1: Batch Analysis feature was not using the specified isotopics.

CHANGES FROM VERSION  5.0.5.5 to VERSION 5.1.0.0 (identical to 5.0.6.0)
New Features:
1: Quadruples are computed for shift registers that provide triples counts.
2: An automatic backup feature for analysis results is available. INCC
   will 'sweep' a copy of the analysis results and the original measurement
   data, into a user-specified location, after each measurement analysis.
3: The Item Id, if defined, is added to the report title bar.
4: The maximum number of cooperating "Integrated Review" analysis tools
   is now 9.
5: Weighted Multiplicity Analysis has an improved initial condition state.
   It now starts with the conventional multiplicity calculated value for
   multiplication.
6: Database warning and error popups can be disabled. This supports
   diagnostic study and data recovery from damaged database files.

Bug Fixes:
1: Weighted Multiplicity Analysis results are fully restored from an INCC
   database backup.
2: Restoring a backed-up database generated an unnecessary warning on a
   missing DATA folder. The warning was removed.
3: Transfer file pick list ignored the last 2 entries in the file list.
4: Unwanted tab characters removed from Verification summary report
   headers.
5: An error with Deming output file specification was fixed.
6: Backup operation when overwriting an existing DB punts, even when the
   overwrite was affirmed.

CHANGES FROM VERSION 5.04 to VERSION 5.0.5.5

1: New installation package.
2: New version numbering scheme: The previous "5.0x" scheme has been
   expanded with an additional numerical suffix.
3: Relaxation of installation location restrictions.
4: New "Weighted" Multiplicity Analysis added to Passive Multiplicity
   analysis.
5: The deadtime coefficient term C has changed.

CHANGES FROM VERSION 5.03 to VERSION 5.04 (5.04 is the last W. Harker update)

1.  Changed curium ratio entry fields to use E format so that
    very small ratios can be entered.
2.  Fixed errors in display of measurement summary.
3.  Added warning message if multiplicity data overflow.
    (last element of multiplicity accidentals array or
    last element of multiplicity reals + accidentals array not zero).
4.  Fixed bug: passive calibration curve parameters would not change
    to the new material type's values when a new material type
    was selected.
5.  Changed default drive for reading and writing files from a:\
    to c:\ everywhere.

CHANGES FROM VERSION 5.02 to VERSION 5.03

1.  Fixed bug: program would crash when trying to do a verification
    measurement if the maximum number of item ids had been reached.
2.  Added option for moisture correction to the multiplication
    corrected doubles rate for known alpha analysis.  Uses ring
    ratio to calculate the correction factor.

CHANGES FROM VERSION 5.01 to VERSION 5.02

1.  Fixed bug: processing unattended mode Radiation Review files
    with a very long path would cause INCC to crash.
2.  Fixed bug: when using the "Select items to delete" dialog box
    for deleting items from the item data entry table, INCC
    would crash if you clicked on the OK or Cancel buttons of
    the "Enter item data" dialog box before exiting the
    "Select items to delete" dialog box.
3.  Added alpha weight parameter to multiplicity analysis when
    Known Alpha chosen.
4.  Fixed bug: can now use File | Get External Data | Initial Data
    to import detector parameters from a version 4.0x file
    created using File | Save As/Export | Initial Data.
5.  When using "Delete items" option in the Item Data Entry dialog
    box, reset all the other fields for a deleted item to either a
    default value or the first choice in a drop down list.
6.  Made change to calculate and display verification measurement
    results when the calculated mass is outside the limits of the
    calibration curve.
7.  Added option for moisture correction to alpha for known alpha
    analysis.  Uses ring ratio to calculate the correction factor.
8.  Added option for passive uranium measurement to the passive
    calibration curve analysis.
9.  Fixed bug: backup and restore of another version 5.0.* database
    would not correctly convert some of the database structures.

CHANGES FROM VERSION 5.00 to VERSION 5.01

1.  Added support for automated processing of curium ratio
    measurements when working with Integrated Review, Operator
    Review and Radiation Review for data acquired in unattended
    mode.
2.  Fixed bug: program would crash if it received an illegal date
    in the operator declaration file created by Operator Review
    when processing data acquired in unattended mode.
3.  Fixed bug: program would sometimes crash when normalization
    history plotted.



INSTALLATION INSTRUCTIONS

NOTE:	For INCC with the INTEGRATED REVIEW SYSTEM installation
	guidance, please refer to the Integrated Review System
	Installation instructions.


STANDALONE INCC INSTALLATION INSTRUCTIONS

NOTE:  This installation may overwrite any existing INCC
       version 5.* and its database.  Be sure to make
       a backup of your current version and all the subdirectories
       before you proceed.  All data in your current database may 
       be overwritten.

Previous versions of INCC will not be affected by
installing INCC 5.1.* in a separate location.  The release package
for this software is an automatic install program.  To invoke the
install program, imitate the following example. The example assumes
the install package media is at drive F:.
Two methods are shown.

Using Explorer:
	display the contents of drive F:
	double click on incc512IAEA.exe

Using Windows Start:
	select Run...
	in the Command Line box, type: F:\incc512IAEA
	click the OK button

UNINSTALL

To uninstall this software, please use the Microsoft Windows Add/Remove
Programs feature.

USING WINDOWS DEMING WITH INCC

The Deming program can be used to calculate and automatically store
calibration coefficients, variances and covariances in the INCC
database for the passive calibration curve, known alpha, add-a-source
and active calibration curve analysis methods.  Acquire measurement
data using Acquire | Calibration Measurements and then go to the
Maintain | Calibration | Deming Curve Fitting option and select
"Fit verification calibration data".  An alternate method is to go
directly to the Deming curve fitting option and type in known doubles
rates and masses determined elsewhere directly into Deming.  For
holdup measurements you can only use the passive calibration curve
and known alpha analysis methods.  When you have acquired the holdup
measurements you want to use for calibration, use the Deming curve
fitting option under calibration and select "Fit holdup data".

TECHNICAL SUPPORT

Problem reports, questions, and suggestions should be directed to:

Joe Longo for software
Phone: 505-667-2452
Fax:   505-665-4433
Email: longo@lanl.gov

William Geist for physics
Phone: 505-667-2527
Fax:   505-665-4433
Email: wgeist@lanl.gov

FILES

In a standalone INCC installation, all INCC files are installed in
a single folder, selected at installation time. For convenience,
this folder is called <INCC installation folder> below.

In an Integrated Review System installation, the INCC files
are separated into three locations for configuration files,
data files and application files.  These folders are denoted
<INCC configuration folder>, <INCC data folder>, and
<INCC application folder> in the section below.

<INCC installation folder> or
<INCC configuration folder>
INCC.INI        Required INCC initialization file for all installations.

<INCC installation folder> or
<INCC application folder>
INCC.EXE	INCC 5.* executable file
INCCCFG.INI     Required INCC initialization file used for configuration
                when INCC is installed with an Integrated Review System.

README.TXT	The file you are reading now
RDM45W32.DLL    DLL used by Raima Data Manager for database functions
DBREV.EXE       Used to read and convert an INCC version
                3.20 or 4.00 database.
DBWORK.DBD      Used to read and convert an INCC version
                3.20 or 4.00 database.
INITDB.EXE      Used to initialize the INCC database
DBU.EXE         Used to backup an existing INCC database when installing
		over an existing INCC installation. Not available for
		Integrated Review System installations.
ncc		INCC user control file
inccuser.pdf	INCC Software Users Manual
inccuser.chm	INCC software help file
dzips32.dll	INCC database compression utility support
dunzips32.dll	INCC database compression utility support

<INCC installation folder>\DATABASE or
<INCC datafolder>\DATABASE
NCC_DB.DBD	Files defining the structure of INCC version 5.00
                database.
NCC_DB.SCH	The contents of	these files determine the version
		of your database.  The date and	size of	these files
		will only change with a different version of the
		database.
ACTIVE.KEY	Raima Data Manager key files
ACT_MULT.KEY
ACT_PASS.KEY
ADDASRC.KEY
CAL_CURV.KEY
CM_RATIO.KEY
COLLAR.KEY
COMP_ISO.KEY
DE_MULTI.KEY
DETECTOR.KEY
HOLDUP.KEY
ISOTOPIC.KEY
KNOWN_A.KEY
KNOWN_M.KEY
METHOD.KEY
MULTI.KEY
RESULTS.KEY
STRATUM.KEY
TRUNCATE.KEY
ACTIVE.DBF	Raima Data Manager data files
ACT_MULT.DBF
ACT_PASS.DBF
ADDASRC.DBF
ALFABETA.DBF
CAL_CURV.DBF
CM_RATIO.DBF
COL_DATA.DBF
COLLAR.DBF
COMP_ISO.DBF
DE_MULTI.DBF
DETECTOR.DBF
HOLDUP.DBF
ISOTOPIC.DBF
ITEM_IDS.DBF
KNOWN_A.DBF
KNOWN_M.DBF
METHOD.DBF
MULTI.DBF
PARMS.DBF
PARMS310.DBF
RESDEMUL.DBF
RESULTS.DBF
RES_ACT.DBF
RES_AD.DBF
RES_AM.DEF
RES_AP.DBF
RES_BIAS.DBF
RES_CC.DBF
RES_COL.DBF
RES_CR.DBF
RES_KA.DBF
RES_KM.DBF
RES_MUL.DBF
RES_PREC.DBF
RES_TM.DBF
RUN.DBF
STRATUM.DBF
TRUNCATE.DBF

<INCC installation folder>\PROCEDUR or
<INCC data folder>\PROCEDUR 
README.TXT      A copy of the file you are reading now.
MT_HELP.TXT	Any procedures written by the user, in a format that
                can be read by Microsoft WordPad.

<INCC installation folder>\INCC_320 or
<INCC data folder>\INCC_320
NCC_DB.DBD      File that defines the structure of the INCC version
                3.20 database.
NCC_DB.SCH      Also needed to define the structure of the INCC
                version 3.20 database.

<INCC installation folder>\INCC_400 or
<INCC data folder>\INCC_400
NCC_DB.DBD      File that defines the structure of the INCC version
                4.00 database.
NCC_DB.SCH      Also needed to define the structure of the INCC
                version 4.00 database.

<INCC installation folder>\INCC_500 or
<<INCC data folder>\INCC_500 
INCC 5.* database import and export working  folder
NCC_DB.DBD      File that defines the structure of the INCC version
                5.00 database.

<INCC installation folder>\DATA\ARCHIVE
<INCC data folder>\DATA\ARCHIVE
                Folders used by INCC to retain exported and
                archived copies of measurement data.

<Windows System>
msxml3.dll 	 Microsoft XML basic services are supported by these
msxml3r.dll	 two files. These DLLs installed only if not found on
		 a Windows 2000 system. Older versions of these files
		 are -not- replaced by this installation.
