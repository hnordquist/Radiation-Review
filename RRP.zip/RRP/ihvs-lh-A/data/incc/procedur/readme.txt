October 12, 2004

LA-UR-99-4634

Safeguards Science and Technology Group
Nonproliferation and International Security Division
Los Alamos National Laboratory

Author:
Bill Harker

Software Version:
This document applies to version 5.0x of INCC.

Sponsorship:
This work was sponsored, in part, by the U. S. Department of Energy,
Office of Safeguards and Security.

Copyright 2004, The Regents Of the University of California.  This
software was produced by the Safeguards Science and Technology Group
(N-1).  This software was produced under a U.S. Government contract
(W-7405-ENG-36) by Los Alamos National Laboratory, which is operated
by the University of California for the U.S. Department of Energy.
The U.S. Government is licensed to use, reproduce, and distribute
this software.  Permission is granted to the public to copy and use
this software without charge, provided that this Notice and any
statement of authorship are reproduced on all copies.
Neither the Government nor the University makes any warranty, express
or implied, or assumes any responsibility for the use of this
software.

PURPOSE

These release notes provide information on INCC version 5.0x

These notes contain a list of changes from versions 3.xx and 4.0x,
instructions on installing the program,
a test for verifying that the install succeeded,
and a list of files that are included with this release.

REFERENCES

For full information about this software consult:

INCC Version 5.00 Users Manual

INCOMPATIBILITIES

Version 5.0x of the software and its database are incompatible with
versions prior to 5.00.  However, an INCC version 3.2x or 4.0x
database created using the File | Backup All Data menu option can
be imported into INCC version 5.0x using the File | Restore All Data
menu option.  All 5.0x versions are completely compatible because
they use an identical database structure.

Beginning with version 3.00, measurement data files created using the
File | Save As/Export | Transfer option can be read into the database
of any more recent version of INCC by using the
File | Get External Data | Transfer option.

Also, beginning with version 3.00, detector parameter files and
calibration parameter files created using the
File | Save As/Export | Initial Data option can be read into the
database of any more recent version of INCC by using the
File | Get External Data | Initial Data option.

This version of the software is only compatible with
Deming version 1.00 or later.

OPERATING SYSTEM REQUIREMENTS

INCC will run on any 32-bit Windows Operating System.
Windows 2000 and XP are recommended.


CHANGES FROM VERSION 5.05 to VERSION 5.04

1: New installation package.
2: Relaxation of installation location restrictions.
3: New "Weighted" Multiplicity Analysis added to Passive Multiplicity
   analysis.

CHANGES FROM VERSION 5.03 to VERSION 5.04

1.  Changed curium ratio entry fields to use E format so that
    very small ratios can be entered.
2.  Fixed errors in display of measurement summary.
3.  Added warning message if multiplicity data overflow.
    (last element of multiplicity accidentals array or
    last element of multiplicity reals + accidentals array not zero).
4.  Fixed bug: passive calibration curve parameters would not change
    to the new material type's values when a new material type
    was selected.
5.  Changed default drive for reading and writing files from a:\
    to c:\ everywhere.

CHANGES FROM VERSION 5.02 to VERSION 5.03

1.  Fixed bug: program would crash when trying to do a verification
    measurement if the maximum number of item ids had been reached.
2.  Added option for moisture correction to the multiplication
    corrected doubles rate for known alpha analysis.  Uses ring
    ratio to calculate the correction factor.

CHANGES FROM VERSION 5.01 to VERSION 5.02

1.  Fixed bug: processing unattended mode Radiation Review files
    with a very long path would cause INCC to crash.
2.  Fixed bug: when using the "Select items to delete" dialog box
    for deleting items from the item data entry table, INCC
    would crash if you clicked on the OK or Cancel buttons of
    the "Enter item data" dialog box before exiting the
    "Select items to delete" dialog box.
3.  Added alpha weight parameter to multiplicity analysis when
    Known Alpha chosen.
4.  Fixed bug: can now use File | Get External Data | Initial Data
    to import detector parameters from a version 4.0x file
    created using File | Save As/Export | Initial Data.
5.  When using "Delete items" option in the Item Data Entry dialog
    box, reset all the other fields for a deleted item to either a
    default value or the first choice in a drop down list.
6.  Made change to calculate and display verification measurement
    results when the calculated mass is outside the limits of the
    calibration curve.
7.  Added option for moisture correction to alpha for known alpha
    analysis.  Uses ring ratio to calculate the correction factor.
8.  Added option for passive uranium measurement to the passive
    calibration curve analysis.
9.  Fixed bug: backup and restore of another version 5.0x database
    would not correctly convert some of the database structures.

CHANGES FROM VERSION 5.00 to VERSION 5.01

1.  Added support for automated processing of curium ratio
    measurements when working with Integrated Review, Operator
    Review and Radiation Review for data acquired in unattended
    mode.
2.  Fixed bug: program would crash if it received an illegal date
    in the operator declaration file created by Operator Review
    when processing data acquired in unattended mode.
3.  Fixed bug: program would sometimes crash when normalization
    history plotted.

CHANGES FROM VERSION 4.06 to VERSION 5.00

1.  Increased the following field lengths:
         Facility from 4 to 12 characters
         Inspection number from from 3 to 12 characters
         Stratum ID from 5 to 12 characters
         Detector type from 4 to 11 characters
2.  When a measurement is imported using the menu option
    File | Get External Data | Transfer, all the parameters
    associated with that measurement (facility, MBA, detector,
    calibration, stratum, stratum rejection limits and
    isotopics) are added to the database.  If there is a
    conflict with already existing parameters, the user has
    the option of never overwriting, always overwriting or
    being prompted to overwrite.
3.  When importing information a browse function is always
    used to get the path and, if appropriate, the file name.
    When exporting information a save as function is always
    used to get the path and file name.
4.  A measurement summary has been added.  It functions the
    same as the verification summary, except that all
    measurements are available for inclusion.
5.  For collar measurements, it is now possible to have up
    to 20 K5 correction factors, and their product is the
    final K5 correction factor.
6.  For manual entry of collar measurement data the passive
    and active data are saved separately so that they are
    both available as the default the next time.
7.  For collar and active/passive measurements you can now
    have a different number of runs for each.
8.  An optional heavy metal correction has been added to the
    passive calibration curve and known alpha analysis
    methods for passive MOX collar measurements.  This
    required the addition of Heavy Metal Declared U Mass
    and Heavy Metal Length to Item Data Table.  The maximum
    number of items is now 392 instead of 480.
9.  Isotopics can now be entered as mass of Pu + Am = 100%
    in addition to the previous method where Pu = 100% and
    the Am is a percentage of the total Pu.
10. There is a new menu option, Help | Procedures which
    opens wordpad to default directory of \INCC_500\procedur.
    Users can append their written procedures to last install
    disk and they will automatically be available on line.
11. A Delete items button has been added to the Item Data
    Entry and Collar Item Data Entry dialog boxes that
    provides a list of items to select for deleting.
12. All measurement listings are now in reverse
    chronological order (most recent first).
13. The Add function for Facility, MBA, Stratum, Detector,
    Material Type, Poison Rod and Glovebox now include a
    dropdown list of all existing choices.  For Add Detector,
    the detector parameters for the new detector will default
    to those of the currently selected detector.
14. Dialog boxes containing tables have been enlarged so
    that less scrolling is necessary.
15. Reports for verification measurement results now include
    a "Passed stratum rejection limits" message instead of
    only a message when there was a failure.
16. Reports for verification measurements now include the
    original declared mass in addition to the decay corrected
    declared mass, and a % Pu240 effective line has been added
    for each passive analysis method.
17. Added support for analysis of unattended add-a-source data
    collected by MIC or shift register collect.
18. Added known alpha analysis option to passive multiplicity
    measurement analysis.

CHANGES FROM VERSION 4.05 to VERSION 4.06

1.  Declared mass reset to zero if a new item id is entered
    in the verification, calibration or holdup acquire
    dialog box.
2.  After a Deming curve fit, the mass limits are set to 10%
    below the lowest mass used for calibration and 10% above
    the highest mass used for calibration.
3.  For all acquire modes the user can now choose between
    "Use number of cycles", "Use doubles for measurement to
    precision" or "Use triples for measurement to precision"
    when deciding how to acuire shift register data. Triples
    can only be selected if the type of shift register is
    MSR4, Canberra 2150, PSR, ISR or AMSR.  For only 
    verification measurements with multiplicity analysis
    selected there is a fourth choice, "Use Pu240e for
    measurement precision".
4.  Improved method of retrying to communicate with the shift
    register when there is a failure.  Will now retry up to 3
    times if unable to get multiplicity data instead of just
    filling multiplicity arrays with zeros after one failure.

CHANGES FROM VERSION 4.04 to VERSION 4.05

1.  When calculating singles, doubles and triples errors using the
    sample standard deviation error method, include the error due
    to background.  This was already done for the theoretical
    error method.
2.  Added capability of using sample standard deviation when
    calculating errors for truncated multiplicity singles, zeros,
    ones and twos.
3.  Don't allow a database backup to a directory that already has
    a database backup.
4.  Fixed bug: a file name or directory name greater than 12
    characters in either the \INCC_400\data directory or the
    \INCC_400\data\archive directory would cause the program
    to crash on startup.
5.  If the shift register type is AMSR, then the maximum count
    time per run is 999 seconds.
6.  Added warning message to results if measurement stopped
    before requested precision was reached.
7.  Collar analysis: always use reference date for decay
    correction instead of also using MRC-95 reference
    singles date.  Removed decay correction for K2.
    Added corrected net doubles rate and error to collar
    results section of assay summary choices.
8.  Changed active multiplicity analysis to use triples
    rate corrected for the source yield factor, which
    it already did for the doubles rate.  Added a divide
    by the square root of the number of good runs to the
    final calculation of the multiplication error.
9.  Added call to database backup dialog box whenever
    INCC is exited.  This gives the user the option of
    backing up the database just before exiting.  If
    not wanted, just click on the Cancel button.
10. Added ability to plot a normalization history for
    the current detector.
11. Fixed bug: stratum authority files read using the
    menu option File | Get External Data | Stratum
    Authority File caused already existing stratum
    rejection limits to be set to incorrect values
    (usually zero).


CHANGES FROM VERSION 4.03 to VERSION 4.04

1.  Fixed bug: If using multiplicity analysis and solving
    for efficiency, then the Pu240e error was calculated
    incorrectly.
2.  Added more significant digits for entry of declared
    masses and ratios in the Acquire | Curium ratio dialog box.
3.  Fixed bug: If AMSR selected as shift register type, then
    when acquiring data the message "invalid field name
                                     C errno = 0: No error"
    would appear.  This does not in any way effect the data
    acquisition.  It is strictly a cosmetic error.
4.  Fixed bug: If using an AMSR, error calculations should
    always use the sample standard deviation method regardless
    of which method was chosen by the user because the theoretical
    method of calculating errors with fast accidentals has not
    been developed yet, and the current theoretical method will
    overestimate the error.


CHANGES FROM VERSION 4.02 to VERSION 4.03

1.  Fixed bug: Deleting a material type could cause all the
    calibration parameters for another material type to be
    lost.
2.  Using new plot library with all extraneous functions
    removed.
3.  Changed the check for restoring an INCC version 3.00
    database to only check the size of the NCC_DB.DBD file,
    and not check the date and time of the file.  This
    was necessary because the file time could change by
    one or two hours during installation so there would not
    be an exact date and time match.
4.  Delete *.dbf and *.key files in \incc_400\incc_300 or
    \incc_400\incc_320 after restoring an INCC 3.00 or
    INCC 3.2x database.
5.  Put "INCC Help" on the on-line help title bar.

CHANGES FROM VERSION 4.01 to VERSION 4.02

1.  Fixed hypertext links in online help.
2.  Changed baud rate for communicating with the JCC-21
    to 9600.
3.  Fixed bug in multiplicity analysis that was introduced
    in version 4.00 when dual energy multiplicity was
    added.  This bug caused the Pu240 effective mass and
    total Pu mass to always be reported as zero.
4.  Changed label on collar parameter entry dialog box
    to make it explicit which parameter is K2.
5.  Fixed minor problems in calculating the alpha error
    and multiplication correction in multiplicity analysis.

CHANGES FROM VERSION 4.00 to VERSION 4.01

1.  Fixed bug: starting INCC with other Integrated Review
    tools installed could prevent INCC from executing because
    a parameter in the INCC.INI file would get overwritten.
2.  Fixed bug: verification measurements using add-a-source
    analysis would crash after completing the first run
    of a measurement.
3.  Fixed bug: known alpha analysis should check for
    Pu238, Pu240 and Pu242 isotopics all zero, and
    return FAIL in that case.
4.  Restore All Data now preserves the default data directory
    that was in effect before the database restore.  This is
    necessary when restoring a version 3.00 or 3.2x database.
5.  Improved detection and handling of bad parameters in the
    Operator Declaration file (only used when in Integrated
    Review mode). 
6.  Added support for an additional parameter in the
    Operator Declaration file that tells INCC whether or
    not a measurement is for a Cf source (normalization).
7.  Added ability to do a passive normalization measurement
    using the Cf252 singles rate and error.
8.  Added ability to use data files from Shift Register
    Review or Integrated Review for initial source
    measurements.
9.  If shift register type is AMSR (with fast accidentals)
    then force error calculation method to be sample
    standard deviation.

CHANGES FROM VERSION 3.23 to VERSION 4.00

1.  Stratum rejection limits are now detector dependent.  This
    required a change in the database structure from version 3.23.
2.  Fixed bug: if passive calibration curve mass was less than
    zero then the error on the mass was unnecessarily forced
    to zero.
3.  Added support for dual energy passive multiplicity.  This
    required an additional database structure, and an
    additional dialog box for entering multiplicity calibration
    parameters that does not need to be accessed if using
    conventional multiplicity analysis.
4.  Reduced processing overhead for each run while acquiring
    data from a shift register.  The time between runs will be
    approximately 3.5 seconds if acquiring mutliplicity data,
    otherwise approximately 1.5 seconds.  This will be true
    regardless of the number of runs requested, but will vary
    slightly depending on the speed of your computer.
5.  Added support for 8 additional serial ports by using 
    Consensys Corp.'s Chili Port board.  The Chili Port board
    requires Windows NT.
6.  Install disks do not have a volume label.
7.  Added support for incc.ini file parameter
    RT_DATA_MATCH_NEVER_SEND_LOCATION needed for review
    of unattended measurements.
8.  Fixed bug: could get Raima Data Manager error message
    when reanalyzing active measurements.
9.  If shift register high voltage is not within 2 volts
    of the target voltage, then wait 1 second before
    testing again (previously waited only .2 seconds).
10. Changed Restore All Data so that there is not always a 3
    minute wait no matter what the size of the database.
    Now only waits until database conversion is complete.
    The Raima Data Manager DOS process that does the
    conversion is now in a visible DOS window.

CHANGES FROM VERSION 3.22 to VERSION 3.23

1.  A4 type paper now prints correctly.
2.  If compiled with IAEA = FALSE, you can password protect the
    Maintenance Menu.
3.  Can now enter negative background values.


CHANGES FROM VERSION 3.21 to VERSION 3.22

1.  Fixed problem with JCC-21 type add-a-source systems by replacing
    PLC DLL with a statically linked PLC library.
2.  Added export of normalization measurements to integrated review
    for reconciliation.
3.  Added support for AMSR shift register with fast accidentals.
    This required turning off checksum tests numbers one and three.
4.  Text that appears bold in results displayed on the screen now
    also appear bold when printed.
5.  Fixed bug: Plot library would not always print graphs when
    running under Windows 95.  Erorr message was:
    "PL.LIB: error in Windows GDI call".
6.  Fixed bug: An active measurement in a verification summary
    would cause the program to crash.
7.  Fixed bug: Can now print list of measurements from verification
    summary selection list.
8.  When importing measurements, if detector does not exist, give
    the user the option of adding the detector.
9.  Increased time to wait for a restore of a version 3.00
    database to 3 minutes to handle databases that are
    several megabytes.
10. Changed maximum buffer size for formatting results from 121
    bytes to 256 bytes.  Old buffer size could cause crash if
    numbers were on the order of 1e100.
11. Added validation of isotopics and composite isotopics
    (100% +- .3%) when writing an isotopics data set to disk.
12. Made A: the default drive whenever using File Open for
    opening a disk file for reading.
13. Fixed bug: Save all calibration parameters did not always use
    the correct detector id.
14. Fixed bug: Reanalyze could cause the item id table to get
    corrupted.
15. At IAEA request, removed the message explaining the two types
    of reanalysis and what the differences are.


CHANGES FROM VERSION 3.20 to VERSION 3.21

1.  Changing Pu date in isotopics data entry dialog box causes Am
    date to also change to the newly entered date.
2.  Improvements have been made to the support for automated
    analysis of unattended measurements imported from Radiation
    Review and operator declarations imported from Operator Review.
3.  Fixed bug: Corrected error in calculation of triples error for
    background measurements and triples rate and triples error for
    normalization measurements if the theoretical error method is
    being used and the normalization constant is not exactly 1.0.
4.  Limited legal values for predelay using a JSR-12 to .5 through
    7.5 in steps of .5.

CHANGES FROM VERSION 3.00 to VERSION 3.20

Support has been added to work with Integrated Review, Operator
Review and Radiation Review for automated processing of measurement
data acquired in unattended mode.  See the Users Manual for details.

1.  Fixed bug:  When item relevant data was read in from a file and
    the material type did not already exist,
    a database error occurred.
2.  Added curium ratio passive analysis method.
3.  Added truncated multiplicity passive analysis method.
4.  Changed method of backing up and restoring entire database to
    use zip and unzip.  This will eliminate the problem of not being
    able to back up databases with very large run files and is also
    much faster.
5.  Fixed bug:  Corrected calculation that occasionally caused a
    very small (~.05 counts/second) error in the triples error
    value.
6.  Added code to strip off leading and trailing blanks and convert
    non-ascii characters to ascii characters in strings read in from
    Stratum Authority and Item Relevant data files.
7.  Added support for new format for importing measurement data from
    Radiation Review.
8.  Added ability to display a verification or normalization
    measurement (it must have previously been imported into INCC)
    corresponding to a peak in Radiation Review.
9.  Added ability to display the data in Radiation Review
    corresponding to an INCC verification measurement.
10. Added ability to use the ones rates from truncated multiplicity
    in the add-a-source analysis.
11. Fixed bug:  Declared mass for calibration measurements now
    decay corrected.
12. Added inspection number to the display of all measurement
    types.  Previously it appeared only with verification and
    holdup measurements.
13. Added ability to reanalyze rates only measurements as
    verification or calibration measurements by using 'Database'
    as the data source under Acquire | Verification and under
    Acquire | Calibration.
14. Added ability to reanalyze calibration measurements as
    verification measurements by using 'Database' as the data source
    under Acquire | Verification.
15. Fixed bug: System could lock up when you click on
    Acquire | Calibration Measurements.
16. Added ability to acquire measurement data using the Canberra
    JSR-14 shift register in either JSR-12 or PSR mode.  It must
    first be put in the desired mode using the Canberra program
    that comes with the JSR-14.
17. Switched from a 16 bit to a 32 bit application (will no longer
    run on computers using the Windows 3.1 operating system).
    (Windows 3.1 no longer supported).
18. Fixed bug: Add-a-source systems using Canberra counters would
    fail to start acquiring data and display the message:
    "GUI Library error.  Non-existent control for ID = 1330 in
    dialog box PLC."
19. Added ability to enter a measurement date and time when you
    acquire data with database as the data source.
20. Added an 'All Measurements' menu option under 'Report' that is
    accessible only in maintenance mode.  This option gives you a
    list of all measurements to choose from when you want a report.
21. Fixed bug: program would occasionally crash when you selected
    Acquire | Verification from the main menu.
22. Fixed bug: under Reanalyze you could type in an item id of
    more than 12 characters.
23. Fixed bug: If the target disk became full and the measurement
    being transferred contained a large number of runs, then the
    File | Save As/Export | Transfer function would indicate that
    a measurement file could not be written to disk when the real
    problem was that the disk was full and a new disk was needed.
24. Added an option in Maintain | QC and Test Parameters to
    calculate: accidentals = totals * totals * gate length (T^2G).
25. Changed isotopics data file format so that up to 1000 sets of
    isotopics can be read into the database at one time.  The file
    format is documented in the Users Manual and on-line help.
26. Date format in tables now the same as date format in edit boxes.
27. Can now tab into and out of tables.
28. Fixed bug: Review of an active calibration measurement would
    cause a crash.
29. Added Material Balance Area to item entry table, making the MBA
    item id dependent.
30. Changed calibration curve calculation of mass to solve equation
    instead of using an iterative method that would incorrectly fail
    for some curves.  The polynomial curve type can have more than
    one solution for a specified doubles rate.  In this case INCC
    selects the smallest mass that is within the upper and lower
    mass limits.  If there is no solution within the mass limits,
    then INCC selects the smallest positive mass.  If there is no
    positive mass, then the least negative mass is selected.







INSTALLATION INSTRUCTIONS

NOTE:  This installation will overwrite any existing INCC
       version 5.0x and its database.  Be sure to make
       a backup of your current version and all the subdirectories
       before you proceed.  All data in your current database will
       be overwritten.

Previous and subsequent versions of INCC will not be affected by
installing INCC 5.0x.  The release disk(s) for this software contain
an automatic install program.  To invoke the install program,
imitate the following example, which assumes that the install disk
number one of three is in drive A:.  Two methods are shown.

Using Explorer:
	display the contents of drive A:
	double click on INSTALL.EXE

Using Windows Start:
	select Run...
	in the Command Line box, type: A:\INSTALL
	click the OK button

When prompted, insert the second and third install disks in drive A:
and type [Enter].


UNINSTALL

To uninstall this software, please use the Microsoft Windows Add/Remove
Programs feature.

USING WINDOWS DEMING WITH INCC

The Deming program can be used to calculate and automatically store
calibration coefficients, variances and covariances in the INCC
database for the passive calibration curve, known alpha, add-a-source
and active calibration curve analysis methods.  Acquire measurement
data using Acquire | Calibration Measurements and then go to the
Maintain | Calibration | Deming Curve Fitting option and select
"Fit verification calibration data".  An alternate method is to go
directly to the Deming curve fitting option and type in known doubles
rates and masses determined elsewhere directly into Deming.  For
holdup measurements you can only use the passive calibration curve
and known alpha analysis methods.  When you have acquired the holdup
measurements you want to use for calibration, use the Deming curve
fitting option under calibration and select "Fit holdup data".

TECHNICAL SUPPORT

Problem reports, questions, and suggestions should be directed to:

Joe Longo for software
Phone:	505-667-2452
Fax:	505-665-4433
Email:	longo@lanl.gov

Bill Geist for physics
Phone:	505-667-2527
Fax:	505-665-4433
Email:	wgeist@lanl.gov

FILES

The following files are installed on your hard disk in the indicated
directories.

<INCC installation folder>
INCC_505.EXE	INCC 5.05 executable file
INCC_500.EXE	INCC 5.04 executable file
INCC.INI        INCC initialization file used for configuration
                when INCC is used with Integrated Review.
README.TXT	The file you are reading now
INCCUSER.HLP	INCC on-line help file
RDM45W32.DLL	DLL used by Raima Data Manager for database functions
DZIP32.DLL	DLL used to zip the entire database
DUNZIP32.DLL	DLL used to unzip a previously zipped database
MSVCRTD.DLL     Microsoft Visual C++ Run Time Library
MFC42.DLL       Microsoft Foundation Classes Library needed for
                graphical user interface.
DBREV.EXE       Used to read and convert an INCC version
                3.20 or 4.00 database.
DBWORK.DBD      Used to read and convert an INCC version
                3.20 or 4.00 database.
INITDB.EXE      Used to initialize the INCC database

<INCC installation folder>\DATABASE
NCC_DB.DBD	Files defining the structure of INCC version 5.00
                database.
NCC_DB.SCH	The contents of	these files determine the version
		of your database.  The date and	size of	these files
		will only change with a different version of the
		database.
ACTIVE.KEY	Raima Data Manager key files
ACT_MULT.KEY
ACT_PASS.KEY
ADDASRC.KEY
CAL_CURV.KEY
CM_RATIO.KEY
COLLAR.KEY
COMP_ISO.KEY
DE_MULTI.KEY
DETECTOR.KEY
HOLDUP.KEY
ISOTOPIC.KEY
KNOWN_A.KEY
KNOWN_M.KEY
METHOD.KEY
MULTI.KEY
RESULTS.KEY
STRATUM.KEY
TRUNCATE.KEY
ACTIVE.DBF	Raima Data Manager data files
ACT_MULT.DBF
ACT_PASS.DBF
ADDASRC.DBF
ALFABETA.DBF
CAL_CURV.DBF
CM_RATIO.DBF
COL_DATA.DBF
COLLAR.DBF
COMP_ISO.DBF
DE_MULTI.DBF
DETECTOR.DBF
HOLDUP.DBF
ISOTOPIC.DBF
ITEM_IDS.DBF
KNOWN_A.DBF
KNOWN_M.DBF
METHOD.DBF
MULTI.DBF
PARMS.DBF
PARMS310.DBF
RESDEMUL.DBF
RESULTS.DBF
RES_ACT.DBF
RES_AD.DBF
RES_AM.DEF
RES_AP.DBF
RES_BIAS.DBF
RES_CC.DBF
RES_COL.DBF
RES_CR.DBF
RES_KA.DBF
RES_KM.DBF
RES_MUL.DBF
RES_PREC.DBF
RES_TM.DBF
RUN.DBF
STRATUM.DBF
TRUNCATE.DBF

<INCC installation folder>\PROCEDUR
README.TXT      A copy of the file you are reading now
		Any procedures written by the user that can be read
                by wordpad

<INCC installation folder>\INCC_320
NCC_DB.DBD      File that defines the structure of the INCC version
                3.20 database.
NCC_DB.SCH      Also needed to define the structure of the INCC
                version 3.20 database.

<INCC installation folder>\INCC_400
NCC_DB.DBD      File that defines the structure of the INCC version
                4.00 database.
NCC_DB.SCH      Also needed to define the structure of the INCC
                version 4.00 database.

<INCC installation folder>\INCC_500
INCC 5.0n database import and export working  folder


<Windows System>
msxml3.dll 	Microsoft XML basic services are supported by these
msxml3r.dll	three files. Installed (if not found) on Windows systems
msxml3d.dll	prior to XP.